using UnityEngine;

public class RouletteController : MonoBehaviour
{
    public float maxSpeed = 500f;      // 最大旋轉速度
    public float acceleration = 300f;  // 加速度
    public float deceleration = 150f;  // 減速度
    public AudioSource spinAudio;      // 輪盤音效

    private float currentSpeed = 0f;
    private enum State { Idle, Accelerating, Decelerating }
    private State currentState = State.Idle;

    void Start()
    {
        // 自動抓取掛載在同物件上的 Audio Source
        if (spinAudio == null)
            spinAudio = GetComponent<AudioSource>();
    }

    void Update()
    {
        // 按下空白鍵開始加速旋轉
        if (Input.GetKeyDown(KeyCode.Space) && currentState == State.Idle)
        {
            currentState = State.Accelerating;
            spinAudio.Play();
        }
        // 按下 S 鍵開始減速至停止
        else if (Input.GetKeyDown(KeyCode.S) && currentState == State.Accelerating)
        {
            currentState = State.Decelerating;
        }

        // 處理速度變化
        if (currentState == State.Accelerating)
        {
            currentSpeed += acceleration * Time.deltaTime;
            if (currentSpeed > maxSpeed) currentSpeed = maxSpeed;
        }
        else if (currentState == State.Decelerating)
        {
            currentSpeed -= deceleration * Time.deltaTime;
            if (currentSpeed <= 0)
            {
                currentSpeed = 0;
                currentState = State.Idle;
                spinAudio.Stop();
            }
        }

        // 根據當前速度套用 Z 軸旋轉
        if (currentSpeed > 0)
        {
            transform.Rotate(0, 0, -currentSpeed * Time.deltaTime);
        }
    }
}